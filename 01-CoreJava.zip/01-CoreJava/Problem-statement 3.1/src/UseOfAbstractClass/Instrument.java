package UseOfAbstractClass;

public abstract class Instrument {
	public abstract void play();
}