package IntegerArray;

public class IntArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,avg,temp;
		int[] array=new int[] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		  for (int i = 0; i < array.length; i++) {  
	           sum = sum + array[i];  
	        }  
		  System.out.println("Sum of all the elements of an array: " + sum+"\n");  
		  array[15]=sum;
		  System.out.println("\nThe sum of elements from index 0 to 14 onto index 15");
		  for(int i=0;i<array.length;i++) {
			  System.out.print(array[i]+" ");
			  }
		  avg=sum/array.length;
		  array[16]=avg;
		  System.out.println("\n\nAverage of all numbers: "+avg);
		  System.out.println("\nAverage of all numbers onto index 16 ");
		  for(int i=0;i<array.length;i++) {
			  System.out.print(array[i]+" ");
			  }
		  System.out.println();
		  for(int i=0;i<array.length;i++) {
			  for(int j=i+1;j<array.length;j++) {
				  if(array[i]>array[j]) {
					  temp=array[i];
					  array[i]=array[j];
					  array[j]=temp;
				  }
			 }
		 }
		  System.out.println();
		  for(int i=0;i<array.length;i++) {
			  System.out.print(array[i]+" ");
			  }
		  System.out.println();
		  System.out.println("\nsmallest number"+array[0]);
		  array[17]=array[0];
		  System.out.println();
		  for(int i=0;i<array.length;i++) {
			  System.out.print(array[i]+" ");
			  }
		
     }
}


