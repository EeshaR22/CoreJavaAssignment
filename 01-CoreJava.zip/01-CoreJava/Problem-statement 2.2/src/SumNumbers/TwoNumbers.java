package SumNumbers;
import java.util.*;
public class TwoNumbers {
	public static void main(String[] args) 
	{
    
    Scanner sc=new Scanner(System.in);
    //int num1 = 1, num2 = 3;
    System.out.print("Enter the number : ");
    int num1=sc.nextInt();   //Declare and Initialize the number of terms
    int num2=sc.nextInt(); 
    //System.out.println("First " + n + " numbers of sequence: ");
    System.out.print(num1 + " "+num2+" ");
    for (int i = 1; i <= 13; ++i)
    {
        
        int sum = num1 + num2;
        num1 = num2;
        num2 = sum;
        System.out.print(sum+" ");
    }
}
}