package Rectangle;

import java.util.Scanner;

public class RectangleMain {
	
		public static int length;
		public static int breadth;
		public static int area;
	
	public static void main(String[] args) {
		RectangleMain rm= new RectangleMain();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 1: ");
		rm.length=sc.nextInt();
		rm.breadth=sc.nextInt();
		rm.area= length * breadth;
		System.out.println("Area of rectangle 1: "+ rm.area+"\n");
		
		//2nd object
		RectangleMain rm2= new RectangleMain();
		System.out.println("Enter length and breadth for rectangle 2: ");
		rm2.length=sc.nextInt();
		rm2.breadth=sc.nextInt();
		rm2.area= length * breadth;
		System.out.println("Area of rectangle 2: "+ rm2.area+"\n");
		
		//3rd object
		RectangleMain rm3= new RectangleMain();
		Scanner sc1=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 3: ");
		rm3.length=sc1.nextInt();
		rm3.breadth=sc1.nextInt();
		rm3.area= length * breadth;
		System.out.println("Area of rectangle 3: "+ rm3.area+"\n");
		
		//4th object
		RectangleMain rm4= new RectangleMain();
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 4: ");
		rm3.length=scan.nextInt();
		rm3.breadth=scan.nextInt();
		rm3.area= length * breadth;
		System.out.println("Area of rectangle 4: "+ rm4.area+"\n");
		
		//5th object
		RectangleMain rm5= new RectangleMain();
		Scanner sc2=new Scanner(System.in);
		System.out.println("Enter length and breadth for rectangle 5: ");
		rm3.length=sc2.nextInt();
		rm3.breadth=sc2.nextInt();
		rm3.area= length * breadth;
		System.out.println("Area of rectangle 5: "+ rm5.area);
		
	}

}
