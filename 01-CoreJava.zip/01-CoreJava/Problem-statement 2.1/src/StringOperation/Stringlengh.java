package StringOperation;
import java.util.Scanner;
public class Stringlengh {

   public static void main(String args[])
   {
      String str, rev = "";
      Scanner sc = new Scanner(System.in);
 
      System.out.println("Enter a string:");
      str = sc.nextLine();
 
      int length = str.length();
      System.out.println("The length of the entered string is : "+length);
      
      String strupper=str.toUpperCase();
      System.out.println("\nString in upper case is : "+strupper);
 
      for ( int i = length - 1; i >= 0; i-- )
         rev = rev + str.charAt(i);
 
      if (str.equals(rev))
         System.out.println("\nAnd "+str+" is a palindrome");
      else
         System.out.println("\nAnd "+str+" is not a palindrome");
 
   }
}